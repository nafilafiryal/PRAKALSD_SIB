public class penjualanBarang {
    barang barang;
    int jumlah;

    public penjualanBarang(barang barang, int jumlah){
        this.barang = barang;
        this.jumlah = jumlah;
    }
}
