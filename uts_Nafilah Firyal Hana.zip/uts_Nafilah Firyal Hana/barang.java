public class barang {

    String kode;
    String namaBarang;
    int stok;
    int hargaSatuan;

    public barang(String kode, String namaBarang, int stok, int hargaSatuan){
        this.kode = kode;
        this.namaBarang = namaBarang;
        this.stok = stok;
        this.hargaSatuan = hargaSatuan;
    }
}